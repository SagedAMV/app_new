import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

val signingPropertiesFile = rootProject.file("keystore.properties")
// Import the type explicitly: Gradle's `java` extension shadows the package here.
val signingProperties = Properties().apply {
    if (signingPropertiesFile.isFile) {
        signingPropertiesFile.inputStream().use { load(it) }
    }
}
val releaseStorePath = signingProperties.getProperty("storeFile")?.takeIf { it.isNotBlank() }
val releaseStoreFile = releaseStorePath?.let { rootProject.file(it) }
val releaseStorePassword = signingProperties.getProperty("storePassword").orEmpty()
val releaseKeyAlias = signingProperties.getProperty("keyAlias").orEmpty()
val releaseKeyPassword = signingProperties.getProperty("keyPassword").orEmpty()
val releaseSigningReady = releaseStoreFile?.isFile == true && releaseStorePassword.isNotBlank() &&
    releaseKeyAlias.isNotBlank() && releaseKeyPassword.isNotBlank()


// Public endpoint only. Never pass R2 keys or provisioning invitation tokens as Gradle properties.
val provisioningUrl = providers.gradleProperty("unihub.provisioningUrl").orElse("").get()
require(provisioningUrl.length <= 2048 && provisioningUrl.none { it.isISOControl() }) {
    "unihub.provisioningUrl must be a bounded public URL without control characters"
}
val provisioningUrlLiteral = "\"" + provisioningUrl.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

android {
    namespace = "com.unihub.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.unihub.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "1.3.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "PROVISIONING_URL", provisioningUrlLiteral)

        vectorDrawables { useSupportLibrary = true }
    }

    signingConfigs {
        if (releaseSigningReady) {
            create("release") {
                storeFile = requireNotNull(releaseStoreFile)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            // ⚠️ قرار متعمّد (مُحدَّث هذه الجلسة) — التصغير مُفعَّل عمداً لأنه صار آمناً:
            //
            // التاريخ: جلسة سابقة (commit 932e6a0) عطّلت التصغير هرباً من كراش إقلاع
            // على جهاز حقيقي لم يُعرف سببه الجذري وقتها. هذه الجلسة شخّصت السبب
            // الجذري وأصلحته من الجذر بدل الهروب منه:
            //
            //   كان R8 full mode (الافتراضي في AGP 8.7) يُسقط «المُنشئ بلا وسائط»
            //   للتطبيقات المولَّدة من Room (*_Impl) — وأهمها قاعدة WorkManager
            //   الداخلية androidx.work.impl.WorkDatabase_Impl — التي تُحمَّل وقت
            //   التشغيل عبر Class.forName + newInstance() فلا يراها R8. لذلك نجح
            //   الفحص القديم «الصنف موجود في الـ dex» بينما انهار الجهاز بـ
            //   NoSuchMethodException — الوجود في الـ dex لا يعني سلامة المُنشئ.
            //
            // الإصلاح: قواعد شاملة في proguard-rules.pro (قسم 1) تُبقي مُنشئات كل
            // RoomDatabase ومولّداتها — الإصلاح نفسه الذي اعتمدته Google رسمياً في
            // Room 2.7.0-beta01 (b/392657750) — مع تحصين مُهيّئ WorkManager في
            // androidx.startup وقواعد kotlinx.serialization الرسمية.
            //
            // أي تعديل هنا مستقبلاً: اقرأ تقرير_جلسة_تفعيل_النسخة_المصغرة.md أولاً.
            isMinifyEnabled = true
            isShrinkResources = true
            if (releaseSigningReady) signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }

        // النسخة الكاملة (غير المصغّرة): جودة Release نفسها (موقَّعة بمفتاح
        // الإصدار) لكن بلا تصغير موارد ولا تصغير شيفرة — لكل من يريد النسخة
        // الكاملة دون معالجة R8. أُنشئت بجلسة التحقق العميق 2026 لتسليم
        // «النسخة الكاملة فقط» إلى مستودع buled، دون المساس بإعدادات
        // النسخة المصغّرة أعلاه (راجع تعليقها قبل أي تعديل هناك).
        create("releaseFull") {
            initWith(getByName("release"))
            isMinifyEnabled = false
            isShrinkResources = false
            if (releaseSigningReady) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/LICENSE"
            excludes += "/META-INF/LICENSE.txt"
            excludes += "/META-INF/NOTICE"
        }
    }

    lint {
        // Lint is a quality gate: a broken build must not be reported as successful.
        abortOnError = true
        checkReleaseBuilds = true
    }
}

dependencies {
    // Core
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.splashscreen)

    // Compose (BOM يوحّد إصدارات كل مكتبات Compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.compose.animation)

    // تنقّل آمن الأنواع (Type-Safe Navigation)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.kotlinx.serialization.json)

    // Room
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // Hilt
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android)

    // DataStore
    implementation(libs.androidx.datastore.preferences)

    // WorkManager لتذكيرات المهام والامتحانات والنسخ الاحتياطي التلقائي
    implementation(libs.androidx.work.runtime)

    // DocumentFile — التعامل مع مجلد المستخدم المختار عبر SAF في النسخ التلقائي
    implementation(libs.androidx.documentfile)

    // حقن العمال (@HiltWorker) لعمّال النسخ الاحتياطي التلقائي
    implementation(libs.androidx.hilt.work)
    ksp(libs.androidx.hilt.compiler)

    // CameraX — التقاط الصور من داخل التطبيق (المكتبة الرسمية الموصى بها من Google)
    implementation(libs.androidx.camera.core)
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)

    // QR generation/decoding: pure Java; CameraX remains the native camera implementation.
    implementation("com.google.zxing:core:3.5.3")
    // Real JSON implementation for portable auth/provisioning tests (not Android's mock jar).
    testImplementation("org.json:json:20240303")

    // اختبارات الوحدة على JVM — بدونها لا تُترجم ملفات test/ أصلاً
    // (إصلاح جلسة التحقق العميق: GalaxyGeometryTest استوردت org.junit بلا تبعية)
    testImplementation(libs.junit)

    // Actual Compose measurement and hit-testing on an Android emulator.
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.androidx.test.junit)

    // أدوات التطوير والاختبار — لا تدخل في حزمة Release.
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)
}
