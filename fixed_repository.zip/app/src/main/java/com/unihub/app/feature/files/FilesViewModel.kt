package com.unihub.app.feature.files

import com.unihub.app.data.cloud.CloudFailureMessages
import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.unihub.app.core.common.Formatters
import com.unihub.app.core.common.UiMessenger
import com.unihub.app.core.validation.InputValidationException
import com.unihub.app.core.validation.InputValidator
import com.unihub.app.core.validation.UserInputRules
import com.unihub.app.data.auth.CloudAuthRules
import com.unihub.app.data.auth.AuthPermission
import com.unihub.app.data.auth.CloudAuthManager
import com.unihub.app.data.cloud.CloudSyncManager
import com.unihub.app.data.cloud.CloudSyncScheduler
import com.unihub.app.data.cloud.CloudTransferBatch
import com.unihub.app.data.cloud.CloudTransferKind
import com.unihub.app.data.cloud.CloudTransferQueueSnapshot
import com.unihub.app.data.cloud.CloudTransferQueueStore
import com.unihub.app.data.cloud.CloudUploadPlan
import com.unihub.app.data.cloud.CloudUploadTarget
import com.unihub.app.data.cloud.RemoteCloudFile
import com.unihub.app.data.local.entity.FileEntity
import com.unihub.app.data.local.entity.FolderEntity
import com.unihub.app.data.repository.FileRepository
import com.unihub.app.data.repository.FolderRepository
import com.unihub.app.feature.share.InboxItem
import com.unihub.app.feature.share.ShareInbox
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.FileNotFoundException
import java.io.IOException
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ViewModel شاشة الملفات داخل مجلد معيّن.
 * التحسين عن المرجع: حالة الشاشة مشتقة عبر [combine] من تدفقات القاعدة مباشرة
 * (البحث والمفضلة يصفّيان لحظياً بلا إعادة استعلام)، وعمليات الاستيراد والنسخ
 * مفوضة لمستودعات/تخزين معزولة.
 *
 * جديد هذه الجولة: وضع التحديد المتعدد (نقر مطول) مع حذف/مشاركة جماعية،
 * ورسائل خطأ استيراد مفصلة حسب السبب الحقيقي.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class FilesViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val folderRepository: FolderRepository,
    private val fileRepository: FileRepository,
    private val shareInbox: ShareInbox,
    private val cloudSyncManager: CloudSyncManager,
    private val cloudTransferQueue: CloudTransferQueueStore,
    private val cloudTransferScheduler: CloudSyncScheduler,
    private val cloudTransferControls: com.unihub.app.notifications.CloudTransferControls,
    private val authManager: CloudAuthManager,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val folderId: Long? = savedStateHandle.get<Long?>("folderId")

    val messenger = UiMessenger()

    // ─── مستشعرات السحابة الباقية لهذه الشاشة فقط ────────────────────────
    // (شارة الزر المضيء وحالة الرفع) — تصفح السحابة وتنزيلها انتقلا إلى
    // الشاشة المستقلة CloudFilesScreen وبوابة حالة CloudFilesViewModel.

    val cloudTransferState = cloudSyncManager.transferState
    val availableRemoteFiles: StateFlow<List<RemoteCloudFile>> = cloudSyncManager.availableRemoteFiles
    val isOnline: StateFlow<Boolean> = cloudSyncManager.isOnline
    /** طابور الخلفية كما تراه شاشة السحابة تمامًا — مصدر واحد للسلوك والإشعار معًا */
    val cloudTransfers = cloudTransferQueue.state.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), CloudTransferQueueSnapshot()
    )

    fun pauseCloudTransfers() {
        viewModelScope.launch {
            performTransferAction("تعذّر إيقاف النقل مؤقتًا؛ حاول مرة أخرى") { cloudTransferControls.pause() }
        }
    }

    fun resumeCloudTransfers() {
        viewModelScope.launch {
            performTransferSchedulingAction(
                scheduledMessage = "تم حفظ الاستئناف، لكن تعذّر تشغيل النقل الآن؛ حاول مرة أخرى",
                failureMessage = "تعذّر استئناف النقل؛ لم يكتمل تحديث الحالة"
            ) { cloudTransferControls.resume() }
        }
    }

    fun retryCloudTransfers() {
        viewModelScope.launch {
            performTransferSchedulingAction(
                scheduledMessage = "تم تجهيز العناصر لإعادة المحاولة، لكن تعذّر تشغيل النقل الآن",
                failureMessage = "تعذّرت إعادة تجهيز العناصر؛ حاول مرة أخرى"
            ) { cloudTransferControls.retryFailed() }
        }
    }

    fun cancelCloudQueued() {
        viewModelScope.launch {
            performTransferAction("تعذّر إكمال إلغاء النقل؛ تحقق من بطاقة النقل وحاول مجددًا") {
                cloudTransferControls.cancelQueued()
            }
        }
    }

    private suspend fun performTransferAction(
        failureMessage: String,
        action: suspend () -> Unit
    ) {
        try {
            action()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            messenger.notifyError(failureMessage)
        }
    }

    private suspend fun performTransferSchedulingAction(
        scheduledMessage: String,
        failureMessage: String,
        action: suspend () -> Boolean
    ) {
        try {
            if (!action()) messenger.notifyError(scheduledMessage)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            messenger.notifyError(failureMessage)
        }
    }

    private val _uploadPlan = MutableStateFlow<CloudUploadPlan?>(null)
    val uploadPlan = _uploadPlan.asStateFlow()
    val cloudUploadReport = cloudSyncManager.lastUploadReport
    val cloudFolders = cloudSyncManager.remoteFolders

    /**
     * وجهة الرفع داخل السحابة. تُحفظ في الـViewModel لا في الخطة وحدها: البطاقة تُغلق وتُفتح
     * عند كل معاينة، ولو ضاع الاختيار لرفع المستخدم ملفاته إلى الجذر وهو يظنّه مختارًا.
     */
    private val _uploadTargetKey = MutableStateFlow<String?>(null)
    val uploadTargetKey = _uploadTargetKey.asStateFlow()
    private val _uploadTargetName = MutableStateFlow<String?>(null)

    fun closeUploadPlan() {
        _uploadPlan.value = null
        _uploadTargetKey.value = null
        _uploadTargetName.value = null
    }

    /** اختيار الجذر = null اسمًا، فيُصفَر الاسم معه ولا يبقى معلّقًا من مجلد سابق */
    fun setUploadTarget(key: String?, name: String?) {
        val normalized = CloudUploadTarget.normalize(key)
        val trimmed = if (normalized == null) null else name?.trim()?.takeIf { it.isNotEmpty() }
        _uploadTargetKey.value = normalized
        _uploadTargetName.value = trimmed
        _uploadPlan.value = _uploadPlan.value?.copy(targetFolderKey = normalized, targetFolderName = trimmed)
    }

    // Planning is local/offline; CloudSyncManager re-verifies Account and server permissions when the queue runs.
    fun previewSelectedUpload(files: List<FileEntity>) {
        viewModelScope.launch {
            CloudAuthRules.checkPermission(authManager.currentAuthenticatedUser(), AuthPermission.UPLOAD).onFailure {
                messenger.notifyError(CloudFailureMessages.or(it, "رفع غير مسموح"))
                return@launch
            }
            _uploadPlan.value = cloudSyncManager.prepareUploadPlan(
                fileIds = files.mapTo(mutableSetOf()) { it.id }, title = "رفع الملفات المحددة",
                targetFolderKey = _uploadTargetKey.value, targetFolderName = _uploadTargetName.value)
        }
    }
    fun previewFolderUpload(id: Long, name: String) {
        viewModelScope.launch {
            CloudAuthRules.checkPermission(authManager.currentAuthenticatedUser(), AuthPermission.UPLOAD).onFailure {
                messenger.notifyError(CloudFailureMessages.or(it, "رفع غير مسموح"))
                return@launch
            }
            _uploadPlan.value = cloudSyncManager.prepareUploadPlan(
                folderIds = setOf(id), title = "رفع مجلد $name ومحتوياته",
                targetFolderKey = _uploadTargetKey.value, targetFolderName = _uploadTargetName.value)
        }
    }
    /**
     * «رفع المحدد» صار طلبًا في طابور الخلفية: يبدأ فورًا إن لم يكن هناك نقل جارٍ،
     * ويستمر بعد إغلاق التطبيق؛ ومتى انقطع الاتصال بقي ما لم يُرفع في الانتظار
     * بلا إعادة ما رُفع (يتخطّاه المدير بالمقارنة الموجودة مسبقًا).
     */
    fun confirmUpload() {
        val plan = _uploadPlan.value ?: return
        viewModelScope.launch {
            try {
                cloudTransferQueue.enqueue(CloudTransferBatch(
                    id = UUID.randomUUID().toString(),
                    kind = CloudTransferKind.UPLOAD,
                    title = plan.title,
                    fileIds = plan.fileIds,
                    folderIds = plan.folderIds,
                    totalBytes = plan.totalBytes,
                    targetFolderKey = plan.targetFolderKey,
                    targetFolderName = plan.targetFolderName
                ))
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                messenger.notifyError("تعذّر حفظ الرفع")
                return@launch
            }

            clearSelection()
            if (!cloudTransferScheduler.enqueueTransfers()) {
                messenger.notifyError("تعذّر بدء الرفع")
                return@launch
            }
            // فشل إشعار النظام لا ينبغي أن يُظهر الرفع كأنه فشل بعد حفظه وجدولته.
            try {
                cloudTransferControls.announceQueued()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // يستمر العامل المجدول؛ رسالة الشاشة التالية هي التأكيد الأساسي.
            }
            val missing = if (plan.missingFiles.isEmpty()) "" else " • لن يُرفع ${plan.missingFiles.size} ملفًا (لم تعد موجودة)"
            messenger.notify("أُضيف للنقل في الخلفية$missing")
        }
    }

    // ─── صندوق المشاركة (ملفات واردة من قائمة مشاركة النظام) ─────────────

    /** الملفات المشتركة التي تنتظر اختيار مجلدها — تظهر في كل شاشات الملفات */
    val inboxItems: StateFlow<List<InboxItem>> = shareInbox.items
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** معرّفات الملفات الموضوعة للتو — لإبرازها بانميشن تلاشي ثم يبهت التمييز */
    private val _recentlyPlaced = MutableStateFlow<Set<Long>>(emptySet())
    val recentlyPlaced: StateFlow<Set<Long>> = _recentlyPlaced.asStateFlow()

    /**
     * نسخ كل ملفات الصندوق إلى المجلد المفتوح حالياً: إدراج منطقي فقط —
     * النسخ الفعلية موجودة سلفاً في المكتبة المسطحة (نفس مبدأ النقل).
     */
    fun placeSharedFilesHere() {
        viewModelScope.launch {
            val placedIds = runCatching { shareInbox.placeAll(folderId) }
                .getOrElse {
                    messenger.notifyError("تعذّر نقل الملفات")
                    return@launch
                }
            if (placedIds.isEmpty()) return@launch
            _recentlyPlaced.value = placedIds.toSet()
            messenger.notify(
                "وُضع " + Formatters.fileCountLabel(placedIds.size) +
                    if (folderId == null) " في المستوى الرئيسي" else " في هذا المجلد"
            )
            launch {
                delay(2_500)
                _recentlyPlaced.value = emptySet()
            }
        }
    }

    /** التخلي عن ملف مشترك واحد وحذف نسخته الفعلية */
    fun removeInboxItem(item: InboxItem) {
        viewModelScope.launch {
            runCatching { shareInbox.remove(item) }
                .onSuccess { messenger.notify("أُهمل الملف المشترك") }
                .onFailure { messenger.notifyError("تعذّر الحذف") }
        }
    }

    /** عداد يُحدَّث بعد أي تغيير على المجلد الحالي كي يُعاد جلب بياناته */
    private val folderVersion = MutableStateFlow(0)

    /**
     * بيانات المجلد الحالي (للعنوان) — الجذر يعيد null. مرتبط بـ [folderVersion]
     * حتى يظهر إعادة التسمية/الحذف في الترويسة فوراً بدل بقاء الاسم القديم.
     */
    val currentFolder: StateFlow<FolderEntity?> = folderVersion
        .flatMapLatest { flow { emit(folderId?.let { folderRepository.getById(it) }) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val query = MutableStateFlow("")
    val searchQuery: StateFlow<String> = query.asStateFlow()

    private val favoritesOnly = MutableStateFlow(false)
    val favoritesOnlyState: StateFlow<Boolean> = favoritesOnly.asStateFlow()

    private val importing = MutableStateFlow(false)
    val isImporting: StateFlow<Boolean> = importing.asStateFlow()

    /** معرّفات الملفات المحددة (وضع النقر المطول) — فارغة = الوضع العادي */
    private val _selection = MutableStateFlow<Set<Long>>(emptySet())
    val selection: StateFlow<Set<Long>> = _selection.asStateFlow()

    val folders: StateFlow<List<FolderEntity>> =
        combine(folderRepository.observeChildren(folderId), query) { folders, q ->
            // القص عند الاستخدام لا أثناء الكتابة (انظر setSearchQuery) حتى
            // تبقى مسافة لوحة المفاتيح قابلة للكتابة في البحث متعدد الكلمات
            val trimmed = q.trim()
            if (trimmed.isBlank()) folders
            else folders.filter { it.name.contains(trimmed, ignoreCase = true) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val files: StateFlow<List<FileEntity>> =
        combine(
            fileRepository.observeInFolder(folderId),
            favoritesOnly,
            query
        ) { files, favOnly, q ->
            val trimmed = q.trim()
            files.filter { file ->
                (!favOnly || file.isFavorite) &&
                    (trimmed.isBlank() || file.name.contains(trimmed, ignoreCase = true))
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** تخزين نص البحث كما كُتب — القص يحدث عند الاستخدام داخل المرشحات فقط */
    fun setSearchQuery(value: String) {
        query.value = value
    }

    fun toggleFavoritesFilter() {
        favoritesOnly.value = !favoritesOnly.value
    }

    // ─── وضع التحديد المتعدد ────────────────────────────────────────────

    /** نقر مطول: يبدأ التحديد أو يبدّل حالة ملف */
    fun toggleSelection(fileId: Long) {
        _selection.value = _selection.value.let { current ->
            if (fileId in current) current - fileId else current + fileId
        }
    }

    fun selectAll(fileIds: List<Long>) {
        _selection.value = fileIds.toSet()
    }

    fun clearSelection() {
        _selection.value = emptySet()
    }

    /** حذف جماعي مع تقرير نجاح/فشل دقيق — يُخرج الشاشة من وضع التحديد بعده */
    fun deleteFiles(files: List<FileEntity>) {
        if (files.isEmpty()) return
        viewModelScope.launch {
            var ok = 0
            var failed = 0
            files.forEach { file ->
                runCatching { fileRepository.delete(file) }
                    .onSuccess { ok++ }
                    .onFailure { failed++ }
            }
            _selection.value = emptySet()
            when {
                failed == 0 -> messenger.notify("حُذف " + Formatters.fileCountLabel(ok))
                ok > 0 -> messenger.notifyError("حذف جزئي")
                else -> messenger.notifyError("تعذّر حذف الملفات")
            }
        }
    }

    /**
     * نقل الملفات المحددة إلى مجلد آخر (أو إلى الجذر). التخزين الفيزيائي مسطح
     * فالنقل تحديث منطقي آمن — لا حركة ملفات على القرص. المجلد الحالي يُستبعد
     * من الوجهات في الواجهة، وهذه حماية دفاعية إضافية إن وصل نفس المجلد.
     */
    fun moveFiles(files: List<FileEntity>, targetFolderId: Long?) {
        if (files.isEmpty()) return
        if (targetFolderId == folderId) {
            messenger.notify("الملفات موجودة في هذا المجلد بالفعل")
            return
        }
        viewModelScope.launch {
            runCatching { fileRepository.moveToFolder(files.map { it.id }, targetFolderId) }
                .onSuccess {
                    messenger.notify(
                        "تم نقل " + Formatters.fileCountLabel(files.size) +
                            if (targetFolderId == null) " إلى المستوى الرئيسي" else ""
                    )
                }
                .onFailure { messenger.notifyError("تعذّر نقل الملفات") }
            _selection.value = emptySet()
        }
    }

    /** تفضيل/إلغاء تفضيل جماعي: إن كان أيٌّ منها غير مفضل فالتفضيل للجميع */
    fun setFavoriteFor(files: List<FileEntity>) {
        if (files.isEmpty()) return
        val target = files.any { !it.isFavorite }
        viewModelScope.launch {
            var failed = 0
            files.forEach { file ->
                runCatching { fileRepository.setFavorite(file.id, target) }
                    .onFailure { failed++ }
            }
            _selection.value = emptySet()
            if (failed == 0) {
                messenger.notify(if (target) "أُضيفت للمفضلة" else "أُزيلت من المفضلة")
            } else {
                messenger.notifyError("تعذّر تحديث المفضلة")
            }
        }
    }

    /**
     * شفاء ذاتي: سجل يشير لملف فيزيائي مفقود — نحذف السجل اليتيم
     * حتى لا تتراكم أشباح في القائمة (يُستدعى عندما يفشل الفتح بسبب الفقدان).
     */
    fun healMissingRecord(file: FileEntity) {
        viewModelScope.launch {
            runCatching { fileRepository.deleteRecord(file) }
                .onSuccess { messenger.notify("حُذف سجل الملف المفقود من القائمة") }
                .onFailure { messenger.notifyError("تعذّر حذف السجل") }
            _selection.value = _selection.value - file.id
        }
    }

    // ─── المجلدات ───────────────────────────────────────────────────────

    fun createFolder(
        name: String,
        description: String,
        color: String,
        onResult: (error: String?) -> Unit = {}
    ) {
        viewModelScope.launch {
            // إصلاح: الخطأ (مثل اسم فيه «/») يعود للوح المفتوح بدل إغلاقه وإظهار
            // رسالة خلفه، فلا يضطر المستخدم لإعادة كتابة الاسم والوصف واختيار اللون.
            val validName = InputValidator.validateName(name)
                .getOrElse {
                    onResult(CloudFailureMessages.or(it, "اسم غير صالح"))
                    return@launch
                }
            // إصلاح: كان يُسمح بمجلدين بنفس الاسم في نفس المكان
            val siblings = runCatching { folderRepository.allOnce() }.getOrDefault(emptyList())
                .filter { it.parentId == folderId }
            if (UserInputRules.hasDuplicateName(validName, siblings, { it.name }, { it.id })) {
                onResult("يوجد مجلد باسم «$validName» هنا بالفعل")
                return@launch
            }
            runCatching {
                folderRepository.create(
                    FolderEntity(
                        name = validName,
                        description = InputValidator.sanitizeText(description),
                        color = color,
                        parentId = folderId
                    )
                )
            }.onSuccess {
                messenger.notify("تم إنشاء المجلد")
                onResult(null)
            }.onFailure { onResult("فشل إنشاء المجلد، حاول مجدداً") }
        }
    }

    fun renameFolder(folder: FolderEntity, newName: String, onResult: (error: String?) -> Unit = {}) {
        viewModelScope.launch {
            val validName = InputValidator.validateName(newName)
                .getOrElse {
                    onResult(CloudFailureMessages.or(it, "اسم غير صالح"))
                    return@launch
                }
            if (validName == folder.name) {
                messenger.notify("الاسم لم يتغير")
                onResult(null)
                return@launch
            }
            val siblings = runCatching { folderRepository.allOnce() }.getOrDefault(emptyList())
                .filter { it.parentId == folder.parentId }
            if (UserInputRules.hasDuplicateName(validName, siblings, { it.name }, { it.id }, ignoreId = folder.id)) {
                onResult("يوجد مجلد آخر باسم «$validName» في نفس المكان")
                return@launch
            }
            runCatching { folderRepository.update(folder.copy(name = validName)) }
                .onSuccess {
                    messenger.notify("تم إعادة التسمية")
                    if (folder.id == folderId) folderVersion.value++
                    onResult(null)
                }
                .onFailure { onResult("فشلت إعادة التسمية، حاول مجدداً") }
        }
    }

    fun deleteFolder(folder: FolderEntity) {
        viewModelScope.launch {
            runCatching { folderRepository.deleteDeep(folder) }
                .onSuccess { messenger.notify("حُذف المجلد ومحتوياته") }
                .onFailure { messenger.notifyError("فشل حذف المجلد") }
        }
    }

    /** لقطة كل المجلدات لمنتقي «نقل إلى مجلد» — تُجلب عند فتح المنتقي فقط */
    suspend fun allFoldersOnce(): List<FolderEntity> = folderRepository.allOnce()

    /** نقل مجلد إلى أب جديد مع رسائل دقيقة لكل سبب رفض */
    fun moveFolder(folder: FolderEntity, newParentId: Long?) {
        viewModelScope.launch {
            val result = runCatching { folderRepository.move(folder, newParentId) }
                .getOrElse {
                    messenger.notifyError("تعذّر نقل المجلد")
                    return@launch
                }
            when (result) {
                FolderRepository.MoveResult.MOVED -> messenger.notify(
                    if (newParentId == null) "نُقل المجلد إلى المستوى الرئيسي"
                    else "تم نقل المجلد"
                )
                FolderRepository.MoveResult.SAME_PLACE ->
                    messenger.notify("المجلد موجود هنا بالفعل")
                FolderRepository.MoveResult.CYCLE ->
                    messenger.notifyError("نقل غير ممكن")
                FolderRepository.MoveResult.MISSING_PARENT ->
                    messenger.notifyError("المجلد غير موجود")
            }
            if (result == FolderRepository.MoveResult.MOVED && folder.id == folderId) {
                folderVersion.value++
            }
        }
    }

    // ─── الملفات ────────────────────────────────────────────────────────

    /** استيراد ملفات من منتقي النظام داخل المجلد الحالي — برسائل فشل مفصلة */
    fun importFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            importing.value = true
            var ok = 0
            var failed = 0
            var failedMsg: String? = null
            uris.forEach { uri ->
                runCatching { fileRepository.import(uri, "*/*", folderId) }
                    .onSuccess { ok++ }
                    .onFailure { e ->
                        failed++
                        failedMsg = when (e) {
                            is InputValidationException -> e.error.message
                            is SecurityException -> "انتهى إذن الوصول لأحد الملفات — اختره مجدداً"
                            is FileNotFoundException -> "أحد الملفات لم يعد متاحاً على الجهاز"
                            is IOException -> "تعذّرت قراءة أحد الملفات من الجهاز"
                            else -> "فشل استيراد أحد الملفات"
                        }
                    }
            }
            importing.value = false
            // إصلاح: الرسالة القديمة «استُورد 2 ملف، فشل <سبب>» لم تذكر عدد الفاشل
            // وكانت تُعرض كرسالة نجاح عادية تختفي وحدها رغم وجود ملفات لم تُستورد.
            val summary = UserInputRules.importSummary(ok, failed, failedMsg)
            if (failed == 0) messenger.notify(summary) else messenger.notifyError(summary)
        }
    }

    /** نسخ شجرة من منتقي النظام إلى التطبيق؛ لا رفع سحابي ضمن الاستيراد. */
    fun importDeviceFolder(uri: Uri) {
        if (importing.value) return
        importing.value = true
        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val root = DocumentFile.fromTreeUri(context, uri)
                        ?: throw IOException("تعذّر قراءة المجلد المختار")
                    val seen = mutableSetOf<String>()
                    var visited = 0; var copied = 0; var failed = 0
                    suspend fun copyTree(directory: DocumentFile, parentId: Long?, depth: Int) {
                        if (depth > 64 || ++visited > 10_000) throw IOException("المجلد أكبر من حد الاستيراد الآمن؛ اختر جزءاً أصغر")
                        if (!seen.add(directory.uri.toString())) return
                        val name = InputValidator.sanitizeName(directory.name ?: "مجلد مستورد").ifBlank { "مجلد مستورد" }
                        val id = folderRepository.create(FolderEntity(name = name, parentId = parentId))
                        for (item in directory.listFiles()) {
                            if (item.isDirectory) copyTree(item, id, depth + 1)
                            else if (item.isFile) {
                                if (++visited > 10_000) throw IOException("وصلنا إلى حد الاستيراد؛ الملفات المكتملة محفوظة")
                                try { fileRepository.import(item.uri, item.type ?: "application/octet-stream", id); copied++ }
                                catch (cancelled: CancellationException) { throw cancelled }
                                catch (_: Exception) { failed++ }
                            }
                        }
                    }
                    copyTree(root, folderId, 0)
                    copied to failed
                }
                messenger.notify("استُورد ${result.first} ملف، تعذّر ${result.second}.")
            } catch (cancelled: CancellationException) { throw cancelled
            } catch (error: Exception) { messenger.notifyError(CloudFailureMessages.or(error, "تعذّر استيراد المجلد"))
            } finally { importing.value = false }
        }
    }

    // ─── المرفقات الجديدة (كاميرا / تسجيل صوتي) ─────────────────────────

    /**
     * حفظ دفعات الصور الملتقطة بالكاميرا داخل المجلد الحالي.
     * كل عنصر زوج (الملف المؤقت في الكاش، الاسم الاختياري الذي أدخله المستخدم).
     * تقرير نجاح/فشل دقيق بنفس نمط الاستيراد من المنتقي.
     */
    fun saveCapturedImages(items: List<com.unihub.app.feature.files.capture.CapturedImageInput>) {
        if (items.isEmpty()) return
        viewModelScope.launch {
            importing.value = true
            var ok = 0
            var failed = 0
            items.forEach { item ->
                runCatching { fileRepository.saveCapturedImage(item.file, item.name, folderId) }
                    .onSuccess { ok++ }
                    .onFailure {
                        failed++
                        runCatching { item.file.delete() } // لا نترك ملفات مؤقتة يتيمة
                    }
            }
            importing.value = false
            when {
                ok > 0 && failed == 0 -> messenger.notify(
                    if (ok == 1) "أُضيفت الصورة إلى الملفات" else "أُضيفت $ok صور إلى الملفات"
                )
                ok > 0 -> messenger.notifyError("حُفظت $ok صور، فشل $failed")
                else -> messenger.notifyError("تعذّر حفظ الصور")
            }
        }
    }

    /** حفظ تسجيل صوتي واحد داخل المجلد الحالي — الملف مؤقت في الكاش */
    fun saveAudioRecording(file: java.io.File, name: String?) {
        viewModelScope.launch {
            importing.value = true
            runCatching { fileRepository.saveAudioRecording(file, name, folderId) }
                .onSuccess { messenger.notify("تم حفظ التسجيل الصوتي") }
                .onFailure {
                    messenger.notifyError("تعذّر حفظ التسجيل")
                    runCatching { file.delete() }
                }
            importing.value = false
        }
    }

    fun renameFile(file: FileEntity, newName: String, onResult: (error: String?) -> Unit = {}) {
        viewModelScope.launch {
            // إصلاح: كتابة «تقرير.pdf» كانت تنتج «تقرير.pdf.pdf» لأن الامتداد يُضاف تلقائياً
            val withoutExt = UserInputRules.stripOwnExtension(newName, file.extension)
            val validName = InputValidator.validateName(withoutExt)
                .getOrElse {
                    onResult(CloudFailureMessages.or(it, "اسم غير صالح"))
                    return@launch
                }
            if (validName == file.name) {
                messenger.notify("الاسم لم يتغير")
                onResult(null)
                return@launch
            }
            runCatching { fileRepository.rename(file, validName) }
                .onSuccess {
                    messenger.notify("تم إعادة التسمية")
                    onResult(null)
                }
                .onFailure { onResult("فشلت إعادة التسمية، حاول مجدداً") }
        }
    }

    fun toggleFavorite(file: FileEntity) {
        viewModelScope.launch {
            runCatching { fileRepository.setFavorite(file.id, !file.isFavorite) }
                .onFailure { messenger.notifyError("تعذّر تحديث المفضلة") }
        }
    }
}

